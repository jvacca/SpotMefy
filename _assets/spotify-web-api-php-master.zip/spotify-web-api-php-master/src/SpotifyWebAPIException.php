<?php
namespace SpotifyWebAPI;

class SpotifyWebAPIException extends \Exception
{
    // dummy
}
